#Enable Microsoft-IIS-Configuration/Operational Log
$logName = 'Microsoft-IIS-Configuration/Operational'
$log = New-Object System.Diagnostics.Eventing.Reader.EventLogConfiguration $logName
$log.IsEnabled=$true
$log.SaveChanges()